PeaZip is a free, Open Source file and archive manager.
Create 7Z, ARC, BR, BZ2, GZ, *PAQ, PEA, TAR, UPX, WIM, ZIP, ZST...
Extract over 180 file formats as ACE, CAB, DMG, ISO, RAR, UDF, ZIPX...

http://www.peazip.org

PeaZip allows to create, convert and extract multiple archives at once, 
create self-extracting archives, bookmark archives and folders, apply 
powerful search filters, scan and open files with custom applications, 
apply strong encryption, split/join files, secure data deletion,
checksum and hash.

To change application's language, use Options > Localization.

Shortcuts to PeaZip's most used functions are available in context
menu and alternatively in SendTo menu.

You can save layout of archiving and extraction operations to speed
up future backup and restore, you can also save job definitions 
(i.e. to be used in scripts), and get detailed job log after each 
operation.
PeaZip can be used from scripts and command line, refer to program's
documentation for details.